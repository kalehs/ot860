function onUse(cid, item, fromPosition, itemEx, toPosition)
 premioDemonOak(cid, item)
 return true
end