function onUse(cid, item, fromPosition, itemEx, toPosition)
 hallowedAxeDemonOak(cid, itemEx, toPosition)
 return true
end