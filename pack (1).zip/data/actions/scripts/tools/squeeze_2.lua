function onUse(cid, item, fromPosition, itemEx, toPosition)
	doCreatureSay(cid, "Oh no! Your tool is jammed and can't be used for a minute.", TALKTYPE_ORANGE_1)
end