function onUse(cid, item, fromPosition, itemEx, toPosition)
	return TOOLS.MACHETE(cid, item, fromPosition, itemEx, toPosition, true)
end
